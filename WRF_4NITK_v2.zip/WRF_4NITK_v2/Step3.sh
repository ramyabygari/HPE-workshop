#!/bin/bash -x
##=====================================================================
##						WRF Input Data for CONUS 2.5 km
##=====================================================================
export USER=/home/nitkworkshop

export BASE=$USER/WRF
cd $BASE/Input

wget -c http://www2.mmm.ucar.edu/WG2bench/conus_2.5_v3/1-RST/RST/rst_6hraaa
wget -c http://www2.mmm.ucar.edu/WG2bench/conus_2.5_v3/1-RST/RST/rst_6hraab
wget -c http://www2.mmm.ucar.edu/WG2bench/conus_2.5_v3/1-RST/RST/rst_6hraac
wget -c http://www2.mmm.ucar.edu/WG2bench/conus_2.5_v3/1-RST/RST/rst_6hraad
wget -c http://www2.mmm.ucar.edu/WG2bench/conus_2.5_v3/1-RST/RST/rst_6hraae
wget -c http://www2.mmm.ucar.edu/WG2bench/conus_2.5_v3/1-RST/RST/rst_6hraaf
wget -c http://www2.mmm.ucar.edu/WG2bench/conus_2.5_v3/1-RST/RST/rst_6hraag
wget -c http://www2.mmm.ucar.edu/WG2bench/conus_2.5_v3/1-RST/RST/rst_6hraah
wget -c http://www2.mmm.ucar.edu/WG2bench/conus_2.5_v3/1-RST/RST/rst_6hraai
wget -c http://www2.mmm.ucar.edu/WG2bench/conus_2.5_v3/1-RST/RST/rst_6hraaj
wget -c http://www2.mmm.ucar.edu/WG2bench/conus_2.5_v3/1-RST/RST/rst_6hraak
wget -c http://www2.mmm.ucar.edu/WG2bench/conus_2.5_v3/1-RST/RST/rst_6hraal
wget -c http://www2.mmm.ucar.edu/WG2bench/conus_2.5_v3/1-RST/RST/rst_6hraam
wget -c http://www2.mmm.ucar.edu/WG2bench/conus_2.5_v3/1-RST/RST/rst_6hraan
wget -c http://www2.mmm.ucar.edu/WG2bench/conus_2.5_v3/1-RST/RST/rst_6hraao
wget -c http://www2.mmm.ucar.edu/WG2bench/conus_2.5_v3/1-RST/RST/rst_6hraap
wget -c http://www2.mmm.ucar.edu/WG2bench/conus_2.5_v3/1-RST/RST/rst_6hraaq
wget -c http://www2.mmm.ucar.edu/WG2bench/conus_2.5_v3/1-RST/RST/rst_6hraar
wget -c http://www2.mmm.ucar.edu/WG2bench/conus_2.5_v3/1-RST/RST/rst_6hraas
wget -c http://www2.mmm.ucar.edu/WG2bench/conus_2.5_v3/1-RST/RST/rst_6hraat
wget -c http://www2.mmm.ucar.edu/WG2bench/conus_2.5_v3/1-RST/RST/rst_6hraau
wget -c http://www2.mmm.ucar.edu/WG2bench/conus_2.5_v3/1-RST/RST/rst_6hraav
wget -c http://www2.mmm.ucar.edu/WG2bench/conus_2.5_v3/1-RST/RST/rst_6hraaw
wget -c http://www2.mmm.ucar.edu/WG2bench/conus_2.5_v3/1-RST/RST/rst_6hraax
wget -c http://www2.mmm.ucar.edu/WG2bench/conus_2.5_v3/1-RST/RST/rst_6hraay
wget -c http://www2.mmm.ucar.edu/WG2bench/conus_2.5_v3/1-RST/RST/rst_6hraaz
wget -c http://www2.mmm.ucar.edu/WG2bench/conus_2.5_v3/1-RST/RST/rst_6hraba
wget -c http://www2.mmm.ucar.edu/WG2bench/conus_2.5_v3/1-RST/RST/rst_6hrabb
wget -c http://www2.mmm.ucar.edu/WG2bench/conus_2.5_v3/1-RST/RST/rst_6hrabc
wget -c http://www2.mmm.ucar.edu/WG2bench/conus_2.5_v3/1-RST/RST/rst_6hrabd
wget -c http://www2.mmm.ucar.edu/WG2bench/conus_2.5_v3/1-RST/RST/rst_6hrabe
wget -c http://www2.mmm.ucar.edu/WG2bench/conus_2.5_v3/1-RST/RST/rst_6hrabf
wget -c http://www2.mmm.ucar.edu/WG2bench/conus_2.5_v3/1-RST/RST/rst_6hrabg

cat rst_6hr* | gunzip -c > wrfrst_d01_2005-06-04_06_00_00

wget http://www2.mmm.ucar.edu/WG2bench/conus_2.5_v3/2-9HR/namelist.input 

wget http://www2.mmm.ucar.edu/WG2bench/conus_2.5_v3/wrfbdy_d01.gz 
gunzip wrfbdy_d01.gz




