#!/bin/bash -x
##=====================================================================
##						Compiling WRF
##=====================================================================

export USER=/home/nitkworkshop

export BASE=$USER/WRF

### Downloading WRF v3.8.1
wget http://www2.mmm.ucar.edu/wrf/src/WRFV3.8.1.TAR.gz -P $BASE/ORI

### Extracting WRF v3.8.1
tar -C $BASE/SRC -zxvf $BASE/ORI/WRFV3.8.1.TAR.gz

##===============================================

# Calling the compilers
export PATH=/opt/ohpc/pub/intel/2018/compilers_and_libraries_2018.0.128/linux/bin/intel64:$PATH
export PATH=/sw/sdev/intel/parallel_studio_xe_2017_update4/impi/2017.3.196/intel64/bin:$PATH

# Setting environment variables for compilers and compiler options
export CC=icc
export CXX=icpc
export FC=ifort
export F9X=ifort
export F77=ifort
export F90=ifort

cp -r configure.scale.wrf $BASE/SRC/WRFV3 ## (This file is shared with you)

## ================================================================
## Compilation of Binary for Scaling purpose:
cd $BASE/SRC/WRFV3
./clean -a
export LIBBASE=$BASE/LIBS
export LD_LIBRARY_PATH=$LIBBASE/lib:$LD_LIBRARY_PATH
export NETCDF=$LIBBASE
export NETCDF_INC=$LIBBASE/include
export NETCDF_LIBS=$LIBBASE/lib
export PNETCDF=$LIBBASE
export WRFIO_NCD_LARGE_FILE_SUPPORT=1
##./configure
cp -r configure.scale.wrf configure.wrf
./compile em_real > compile.scale.log
cp -r $BASE/SRC/WRFV3/main/wrf.exe $BASE/BIN/wrf.scale.exe

## ================================================================