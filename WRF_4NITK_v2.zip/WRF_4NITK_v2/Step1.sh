#!/bin/bash -x

## Making requred directories:
export USER=/home/nitkworkshop

mkdir -p $USER/WRF
export BASE=$USER/WRF

## ================================================================
mkdir -p $BASE/ORI ## Contains original tar files
mkdir -p $BASE/SRC ## contains extracted tar files
mkdir -p $BASE/LIBS ## LIBS are installed here
mkdir -p $BASE/run ## for mandotory support files while running WRF
mkdir -p $BASE/RUNNING ## WRF is run here
mkdir -p $BASE/BIN ## Different binaries are kept here
mkdir -p $BASE/Input ## Different binaries are kept here

## ==============================================================
### Downloading original tar files:

### Downloading libraries 
wget https://www.gfd-dennou.org/library/netcdf/unidata-mirror/netcdf-4.6.1.tar.gz -P $BASE/ORI
wget https://www.unidata.ucar.edu/downloads/netcdf/ftp/netcdf-fortran-4.4.4.tar.gz -P $BASE/ORI
wget http://cucis.ece.northwestern.edu/projects/PnetCDF/Release/parallel-netcdf-1.9.0.tar.gz -P $BASE/ORI

## ==============================================================

### Extracting libraries
tar -C $BASE/SRC -zxvf $BASE/ORI/netcdf-4.6.1.tar.gz
tar -C $BASE/SRC -zxvf $BASE/ORI/netcdf-fortran-4.4.4.tar.gz
tar -C $BASE/SRC -zxvf $BASE/ORI/parallel-netcdf-1.9.0.tar.gz

## ==============================================================

# Calling the compilers

export PATH=/opt/ohpc/pub/intel/2018/compilers_and_libraries_2018.0.128/linux/bin/intel64:$PATH
export PATH=/sw/sdev/intel/parallel_studio_xe_2017_update4/impi/2017.3.196/intel64/bin:$PATH

# Setting environment variables for compilers and compiler options
export CC=icc
export CXX=icpc
export FC=ifort
export F9X=ifort
export F77=ifort
export F90=ifort

##===============================================
## Compilimg Libraries:

export LIBBASE=$BASE/LIBS

cd $BASE/SRC/netcdf-4.6.1
export LD_LIBRARY_PATH=$LIBBASE/lib:$LD_LIBRARY_PATH
./configure --disable-netcdf-4 --prefix=$LIBBASE LDFLAGS=-L$LIBBASE/lib CPPFLAGS=-I$LIBBASE/include CFLAGS=-fPIC CXXFLAGS=-fPIC --enable-shared
make
make install

cd $BASE/SRC/netcdf-fortran-4.4.4
export LD_LIBRARY_PATH=$LIBBASE/lib:$LD_LIBRARY_PATH
./configure LDFLAGS=-L$LIBBASE/lib CPPFLAGS=-I$LIBBASE/include CFLAGS=-fPIC CXXFLAGS=-fPIC --prefix=$LIBBASE
make
make install

cd $BASE/SRC/parallel-netcdf-1.9.0
export LD_LIBRARY_PATH=$LIBBASE/lib:$LD_LIBRARY_PATH
./configure LDFLAGS=-L$LIBBASE/lib CPPFLAGS=-I$LIBBASE/include CFLAGS=-fPIC CXXFLAGS=-fPIC --prefix=$LIBBASE
make
make install

cd $USER

