#!/bin/bash -x

#SBATCH --nodes=8
#SBATCH --ntasks-per-node=40
#SBATCH --time=00:50:00
#SBATCH --job-name=WRF_NITK
#SBATCH -c 2


export BASEDIR=/home/nitkworkshop/WRF/RUNNING
export RUNDIR=$BASEDIR/run-jobid-${SLURM_JOBID}
mkdir -p $RUNDIR

cd $RUNDIR

export PATH=/opt/ohpc/pub/intel/2018/compilers_and_libraries_2018.0.128/linux/bin/intel64:$PATH
export PATH=/sw/sdev/intel/parallel_studio_xe_2017_update4/impi/2017.3.196/intel64/bin:$PATH

export CC=icc
export CXX=icpc
export FC=ifort
export F9X=ifort
export F77=ifort
export F90=ifort


ulimit -s unlimited

export OMP_NUM_THREADS=1
export WRF_NUM_TILES=16
export WRFIO_NCD_LARGE_FILE_SUPPORT=1

export LD_LIBRARY_PATH=/home/nitkworkshop/WRF/LIBS/lib:$LD_LIBRARY_PATH

cp -r /home/nitkworkshop/WRF/BIN/wrf.scale.exe .
cp -r /home/nitkworkshop/WRF/SRC/WRFV3/run/* .

cp -r /home/nitkworkshop/WRF/Input/namelist.input namelist.input
ln -s /home/nitkworkshop/WRF/Input/wrfbdy_d01 .
ln -s /home/nitkworkshop/WRF/Input/wrfrst_d01_2005-06-04_06_00_00 .

echo “Job started at:” `date`

/usr/bin/time -pv mpirun -np 320 -genv OMP_NUM_THREADS=1 -genv I_MPI_DEBUG=5 -hostfile /home/nitin/hostfile-jobid-${SLURM_JOBID} /home/nitkworkshop/WRF/BIN/wrf.scale.exe -genv I_MPI_PIN_PROCESSOR_LIST=0-39 2>&1 | tee  wrf.out.${SLURM_JOBID}

echo “Job finished at:” `date`


