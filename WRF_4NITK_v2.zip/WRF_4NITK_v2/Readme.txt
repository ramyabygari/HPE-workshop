## Follow this step-by-step to compile and run WRF:

# Step 1:
Compile the libaries using Step1.sh
Note: please check the path: export USER=/home/nitkworkshop

# Step 2:
Compile WRF using Step2.sh
Note: please check the path: export USER=/home/nitkworkshop
      in configure.scale.wrf please correct path NETCDF_PATH_CHANGE = /home/nitkworkshop (#change to /home)

# Step 3:
Download input data using Step3.sh (will take time it is ~26GB)
Note: please check the path: export USER=/home/nitkworkshop

# Step 4:
copy script_wrf_slurm.sh for running WRF to /home/nitkworkshop/WRF/RUNNING
Please modify slurm parameters in the beginning of the script as per your cluster settings!




